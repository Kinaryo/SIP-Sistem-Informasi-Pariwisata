@extends('all.layouts.app-all')

@section('title', 'Tambah Wisata')
@section('page-title', 'Tambah Destinasi Wisata')

@section('content')
<div class="container py-5">
    <div class="text-center mb-4">
        <h2 class="fw-bold">Tambah Tempat Wisata</h2>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body">
            <form action="{{ route('dashboard.storeTourismPlaces') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row g-3">

                    {{-- NAMA WISATA --}}
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nama Wisata</label>
                        <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
                    </div>

                    {{-- KATEGORI --}}
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Kategori</label>
                        <select name="category_id" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- LOKASI --}}
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Provinsi</label>
                        <input type="text" name="province" class="form-control" value="{{ old('province') }}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Kota / Kabupaten</label>
                        <input type="text" name="city" class="form-control" value="{{ old('city') }}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Kecamatan / Distrik</label>
                        <input type="text" name="district" class="form-control" value="{{ old('district') }}">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Alamat Lengkap</label>
                        <input type="text" name="address" class="form-control" value="{{ old('address') }}">
                    </div>

                    {{-- MAP PICKER --}}
                    <div class="col-12">
                        <label class="form-label fw-semibold">Pilih Lokasi di Peta</label>
                        <div id="map" style="height: 400px;"></div>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="latitude" id="latitude" value="{{ old('latitude') }}" class="form-control mt-2" placeholder="Latitude" readonly>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="longitude" id="longitude" value="{{ old('longitude') }}" class="form-control mt-2" placeholder="Longitude" readonly>
                    </div>

                    {{-- DESKRIPSI --}}
                    <div class="col-12">
                        <label class="form-label fw-semibold">Deskripsi</label>
                        <textarea name="description" rows="4" class="form-control" required>{{ old('description') }}</textarea>
                    </div>

                    {{-- HARGA --}}
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Harga Tiket</label>
                        <input type="number" name="ticket_price" class="form-control" value="{{ old('ticket_price', 0) }}" min="0" required>
                    </div>

                    {{-- JAM BUKA / TUTUP --}}
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Jam Buka</label>
                        <input type="time" name="open_time" class="form-control" value="{{ old('open_time') }}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Jam Tutup</label>
                        <input type="time" name="close_time" class="form-control" value="{{ old('close_time') }}" required>
                    </div>

                    {{-- KONTAK --}}
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Kontak</label>
                        <input type="text" name="contact" class="form-control" value="{{ old('contact') }}">
                    </div>

                    {{-- COVER IMAGE --}}
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Cover Image</label>
                        <input type="file" name="cover_image" class="form-control" accept="image/*">
                    </div>

                    {{-- FASILITAS --}}
                    <div class="col-12">
                        <label class="form-label fw-semibold">Fasilitas</label>
                        <div class="row">
                            @foreach ($facilities as $facility)
                                <div class="col-md-3 col-sm-4 col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="facilities[]" value="{{ $facility->id }}" id="facility_{{ $facility->id }}" {{ in_array($facility->id, old('facilities', [])) ? 'checked' : '' }}>
                                        <label class="form-check-label" for="facility_{{ $facility->id }}">{{ $facility->name }}</label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    {{-- GALERI --}}
                    <div class="col-12">
                        <label class="form-label fw-semibold">Galeri Wisata</label>
                        <div id="gallery-container">
                            @if(old('gallery'))
                                @foreach(old('gallery') as $i => $item)
                                    <div class="row g-2 mb-2 gallery-item">
                                        <div class="col-md-6">
                                            <input type="file" name="gallery[{{ $i }}][image]" class="form-control" accept="image/*">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" name="gallery[{{ $i }}][title]" class="form-control" placeholder="Judul Gambar" value="{{ $item['title'] ?? '' }}">
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <div class="row g-2 mb-2 gallery-item">
                                    <div class="col-md-6">
                                        <input type="file" name="gallery[0][image]" class="form-control" accept="image/*">
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="gallery[0][title]" class="form-control" placeholder="Judul Gambar">
                                    </div>
                                </div>
                            @endif
                        </div>
                        <button type="button" id="add-gallery" class="btn btn-sm btn-outline-primary mt-2">Tambah Gambar</button>
                    </div>

                </div>

                {{-- ACTION --}}
                <div class="mt-4 d-flex justify-content-between">
                    <a href="{{ route('dashboard') }}" class="btn btn-secondary btn-sm">Kembali</a>
                    <button type="submit" class="btn btn-primary btn-sm">Simpan Wisata</button>
                </div>

            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<!-- Leaflet -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- SweetAlert2 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
/* ================= MAP PICKER ================= */
const map = L.map('map').setView([-2.548926, 118.0148634], 5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data &copy; OpenStreetMap contributors',
}).addTo(map);

let marker;
function setMarker(lat, lng) {
    if(marker) map.removeLayer(marker);
    marker = L.marker([lat, lng]).addTo(map);
    document.getElementById('latitude').value = lat;
    document.getElementById('longitude').value = lng;
}
map.on('click', function(e) { setMarker(e.latlng.lat, e.latlng.lng); });

@if(old('latitude') && old('longitude'))
    setMarker({{ old('latitude') }}, {{ old('longitude') }});
    map.setView([{{ old('latitude') }}, {{ old('longitude') }}], 12);
@endif

/* ================= DYNAMIC GALLERY ================= */
let galleryIndex = {{ old('gallery') ? count(old('gallery')) : 1 }};
document.getElementById('add-gallery').addEventListener('click', function() {
    if(galleryIndex >= 10) { alert("Maksimal 10 gambar."); return; }
    const container = document.getElementById('gallery-container');
    const div = document.createElement('div');
    div.classList.add('row','g-2','mb-2','gallery-item');
    div.innerHTML = `
        <div class="col-md-6">
            <input type="file" name="gallery[${galleryIndex}][image]" class="form-control" accept="image/*">
        </div>
        <div class="col-md-6">
            <input type="text" name="gallery[${galleryIndex}][title]" class="form-control" placeholder="Judul Gambar">
        </div>
    `;
    container.appendChild(div);
    galleryIndex++;
});

/* ================= SWEETALERT LOADING SAAT SUBMIT ================= */
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e){
        const submitBtn = form.querySelector('[type="submit"]');
        if(submitBtn) submitBtn.disabled = true;

        Swal.fire({
            title: 'Sedang mengirim data...',
            html: 'Tunggu sebentar.',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        setTimeout(() => form.submit(), 50);
        e.preventDefault();
    });
});
</script>
@endpush
